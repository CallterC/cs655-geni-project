'''
Author: Jinqi Lu, Quansen Wang
Prof. Matta
CS 655 PA3 GENI-MINILAB
Boston University
December 8, 2022
python management.py
This is the config file contains all available hosts and their port
'''
hosts = [
    ["10.170.47.11", 9102],
    ["10.170.47.12", 9102],
    ["10.170.47.13", 9102],
    ["10.170.47.14", 9102],
    ["10.170.47.15", 9102]
]
